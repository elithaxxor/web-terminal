document.addEventListener('DOMContentLoaded', function() {
    // Initialize terminal with custom theme
    const term = new Terminal({
        fontFamily: 'JetBrains Mono, monospace',
        fontSize: 14,
        lineHeight: 1.5,
        cursorBlink: true,
        cursorStyle: 'block',
        theme: {
            background: '#1a1d21',
            foreground: '#ffffff',
            cursor: '#4ade80',
            selection: 'rgba(74, 222, 128, 0.3)',
            black: '#1a1d21',
            red: '#ef4444',
            green: '#4ade80',
            yellow: '#fbbf24',
            blue: '#60a5fa',
            magenta: '#c084fc',
            cyan: '#22d3ee',
            white: '#ffffff',
            brightBlack: '#4b5563',
            brightRed: '#f87171',
            brightGreen: '#86efac',
            brightYellow: '#fcd34d',
            brightBlue: '#93c5fd',
            brightMagenta: '#d8b4fe',
            brightCyan: '#67e8f9',
            brightWhite: '#ffffff'
        }
    });

    // Create and load addons
    const fitAddon = new FitAddon.FitAddon();
    const webLinksAddon = new WebLinksAddon.WebLinksAddon();
    const searchAddon = new SearchAddon.SearchAddon();

    term.loadAddon(fitAddon);
    term.loadAddon(webLinksAddon);
    term.loadAddon(searchAddon);

    // Open terminal in container
    term.open(document.getElementById('terminal-container'));
    fitAddon.fit();

    // Welcome message
    term.writeln('\x1b[1;32mWelcome to Interactive Shell!\x1b[0m');
    term.writeln('\x1b[90mType "help" for available commands.\x1b[0m');
    term.writeln('');

    // Command history
    let history = [];
    let historyIndex = 0;
    
    // Current command buffer
    let currentCommand = '';
    let prompt = '\x1b[32m$\x1b[0m ';

    // Show initial prompt
    term.write(prompt);

    // Available commands
    const commands = {
        help: () => {
            term.writeln('Available commands:');
            term.writeln('  clear    - Clear the terminal screen');
            term.writeln('  echo     - Print text to the terminal');
            term.writeln('  ls       - List files in current directory');
            term.writeln('  pwd      - Print working directory');
            term.writeln('  date     - Show current date and time');
            term.writeln('  whoami   - Show current user');
            term.writeln('  uname    - Show system information');
            term.writeln('  history  - Show command history');
            term.writeln('  help     - Show this help message');
            term.writeln('');
        },
        clear: () => {
            term.clear();
        },
        echo: (args) => {
            term.writeln(args.join(' '));
        },
        ls: () => {
            term.writeln('\x1b[34mDocuments/\x1b[0m');
            term.writeln('\x1b[34mDownloads/\x1b[0m');
            term.writeln('\x1b[34mprojects/\x1b[0m');
            term.writeln('README.md');
            term.writeln('.bashrc');
        },
        pwd: () => {
            term.writeln('/home/user');
        },
        date: () => {
            term.writeln(new Date().toString());
        },
        whoami: () => {
            term.writeln('guest');
        },
        uname: () => {
            term.writeln('Linux InteractiveShell 6.1.0 x86_64');
        },
        history: () => {
            history.forEach((cmd, i) => {
                term.writeln(`${i + 1}  ${cmd}`);
            });
        }
    };

    // Handle input
    term.onKey(({ key, domEvent }) => {
        const printable = !domEvent.altKey && !domEvent.ctrlKey && !domEvent.metaKey;

        if (domEvent.keyCode === 13) { // Enter
            term.writeln('');
            if (currentCommand.trim().length > 0) {
                const args = currentCommand.trim().split(' ');
                const cmd = args[0];
                
                if (commands[cmd]) {
                    try {
                        commands[cmd](args.slice(1));
                    } catch (err) {
                        term.writeln(`\x1b[31mError: ${err.message}\x1b[0m`);
                    }
                } else {
                    term.writeln(`\x1b[31mCommand not found: ${cmd}\x1b[0m`);
                }

                history.push(currentCommand);
                historyIndex = history.length;
            }
            currentCommand = '';
            term.write(prompt);
        } else if (domEvent.keyCode === 8) { // Backspace
            if (currentCommand.length > 0) {
                currentCommand = currentCommand.slice(0, -1);
                term.write('\b \b');
            }
        } else if (domEvent.keyCode === 38) { // Up arrow
            if (historyIndex > 0) {
                historyIndex--;
                currentCommand = history[historyIndex];
                term.write('\x1b[2K\r' + prompt + currentCommand);
            }
        } else if (domEvent.keyCode === 40) { // Down arrow
            if (historyIndex < history.length) {
                historyIndex++;
                currentCommand = historyIndex === history.length ? '' : history[historyIndex];
                term.write('\x1b[2K\r' + prompt + currentCommand);
            }
        } else if (domEvent.keyCode === 9) { // Tab
            domEvent.preventDefault();
            // TODO: Implement tab completion
        } else if (printable) {
            currentCommand += key;
            term.write(key);
        }
    });

    // Handle window resize
    window.addEventListener('resize', () => {
        fitAddon.fit();
    });

    // Handle OS selection change
    const osSelect = document.querySelector('select');
    osSelect.addEventListener('change', () => {
        term.writeln('');
        term.writeln(`\x1b[33mSwitching to ${osSelect.value}...\x1b[0m`);
        term.writeln('\x1b[31mNote: Pro features require a subscription\x1b[0m');
        term.writeln('');
        term.write(prompt);
    });

    // Mobile menu toggle
    const mobileMenuButton = document.querySelector('button.md\\:hidden');
    const mobileMenu = document.createElement('div');
    mobileMenu.className = 'mobile-menu';
    mobileMenu.innerHTML = `
        <a href="/terminal.html">Terminal</a>
        <a href="https://desktop.interactiveshell.com">Desktop</a>
        <a href="/drive">IDE Drive</a>
        <a href="/pricing">Pricing</a>
        <a href="/training">Training</a>
        <a href="/blog">Blog</a>
        <a href="/about">About</a>
        <a href="/contact">Contact</a>
    `;
    document.body.appendChild(mobileMenu);

    mobileMenuButton.addEventListener('click', () => {
        mobileMenu.classList.toggle('active');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', (e) => {
        if (mobileMenu.classList.contains('active') && 
            !mobileMenu.contains(e.target) && 
            !mobileMenuButton.contains(e.target)) {
            mobileMenu.classList.remove('active');
        }
    });
});
